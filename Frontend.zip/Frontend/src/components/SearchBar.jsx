import React from "react";

function SearchBar() {
    return(
        <form className="d-flex align-items-center">
        <input
          type="text"
          className="form-control me-2 border-secondary"
          placeholder="Search..."
          style={{
            borderRadius: '25px',
            height: '36px',
          }}
        />
        <span
          className="text-primary fs-5 ms-2"
          onClick={(e) => {
            e.preventDefault();
            alert('Search triggered'); // Replace this with actual search functionality
          }}
          style={{ cursor: 'pointer' }}
        >
          🔍
        </span>
      </form>
    )
}
export default SearchBar;