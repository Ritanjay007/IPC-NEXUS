import "./About.css";

const AboutUs = () => {
  return (
    <div className="about-container">
      <h1>About Us</h1>
      <p>
        Welcome to our platform, where we provide valuable learning resources
        on various subjects, including legal references for police officers
        and criminal law insights for public awareness.
      </p>
      <h2>Our Mission</h2>
      <p>
        Our mission is to ensure that police officers, legal professionals,
        and the general public have quick and easy access to crucial IPC sections
        to aid in FIR filing, law enforcement, and understanding criminal laws.
      </p>
      <h2>What We Offer</h2>
      <ul>
        <li>A searchable IPC section database for FIR filing.</li>
        <li>Instant access to legal provisions and punishments.</li>
        <li>Structured information on criminal offenses.</li>
        <li>Quick reference guides for law enforcement officers.</li>
        <li>Criminal law information for public awareness and legal education.</li>
      </ul>
      <h2>Quickly Search IPC Sections</h2>
      <p>
        Our platform allows police officers and individuals to quickly find IPC sections,punishments
        relevant to different types of offenses, ensuring they have the
        
        right information while writing FIRs or understanding the legal system.
      </p>
      <input type="text" placeholder="Search IPC Sections for FIR or Criminal Laws..." />
      <h2>Why This is Important</h2>
      <ul>
        <li>Ensures accurate legal information for FIRs.</li>
        <li>Reduces errors in legal documentation.</li>
        <li>Speeds up law enforcement processes.</li>
        <li>Empowers officers and the public with legal knowledge at their fingertips.</li>
        <li>Enhances legal literacy and helps individuals understand their rights.</li>
      </ul>
      <h2>Crime and Punishment Search</h2>
      <p>
        Our platform provides a crime punishment search tool that allows users to look up
        offenses and their corresponding legal punishments. This is useful for both law enforcement
        and individuals seeking to understand criminal laws.
      </p>
      <h2>Join Us</h2>
      <p>
        Utilize our platform to enhance efficiency in policing, law enforcement, and legal education.
        Search, learn, and apply legal knowledge instantly.
      </p>
    </div>
  );
};

export default AboutUs;
