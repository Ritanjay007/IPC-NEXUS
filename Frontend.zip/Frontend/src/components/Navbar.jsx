import React from 'react';
import { Link } from 'react-router-dom';
import './Components.css'
const Navbar = ({ branches }) => {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light shadow-sm">
      <div className="container">
        {/* Brand / Logo */}
        <a className="navbar-brand fw-bold fs-4 text-primary" href="/">
          IPC Nexus
        </a>

        {/* Mobile Toggle Button */}
        <button
          className="navbar-toggler"  
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Navbar Links */}
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav me-auto">
            {/* About Section */}
            <li className="nav-item">
              <a className="nav-link text-secondary fw-semibold" href="/about">
                About Us
              </a>
            </li>

            {/* Dropdown for Laws */}
            <li className="nav-item dropdown">
              <a
                className="nav-link dropdown-toggle text-secondary fw-semibold"
                href="#"
                id="branchesDropdown"
                role="button"
                data-bs-toggle="dropdown"
                aria-expanded="false"
              >
                Laws
              </a>
              <ul className="dropdown-menu">
                {branches.map((branch, index) => (
                  <li key={index}>
                    <a
                      className="dropdown-item text-secondary fw-semibold"
                      href={`#${branch.toLowerCase().replace(/\s/g, '-')}`}
                    >
                      {branch}
                    </a>
                  </li>
                ))}
              </ul>
            </li>

            {/* New Buttons for Features */}
            <li className="nav-item">
  <Link className="nav-link text-secondary fw-semibold" to="/register-complaint">
    Register Complaint
  </Link>
</li>
            <li className="nav-item">
              <a
                className="nav-link text-secondary fw-semibold"
                href="/IPCSections"
    
              >
                IPC Sections
              </a>
            </li>

            <li className="nav-item">
              <a className="nav-link text-secondary fw-semibold" href="#laws">
                Learn About Laws
              </a>
            </li>
           

          </ul>



        </div>
      </div>
    </nav>
  );
};

export default Navbar;
