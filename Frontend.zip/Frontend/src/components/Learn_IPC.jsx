import { useState, useEffect } from "react";
import "./Learn_IPC.css";

const IPCSectionsTable = () => {
  const [sections, setSections] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(false);

  const fetchData = async (query = "") => {
    try {
      setLoading(true);
      const response = await fetch("http://localhost:5000/search", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ query }),
      });
      const data = await response.json();
      setSections(data);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  useEffect(() => {
    const debounceTimer = setTimeout(() => {
      fetchData(searchTerm);
    }, 300);

    return () => clearTimeout(debounceTimer);
  }, [searchTerm]);

  return (
    <div className="ipc-container">
      <div className="ipc-content">
        <div className="ipc-header">
          <h2 className="ipc-title">Indian Penal Code</h2>
          <p className="ipc-subtitle">Explore and Search IPC Sections</p>
        </div>

        <div className="search-container">
          <input
            type="text"
            placeholder="Search by section number or offense description..."
            className="search-input"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <span className="search-icon">
            <svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
              />
            </svg>
          </span>
        </div>

        <div className="table-container">
          {loading ? (
            <div className="loading">Loading...</div>
          ) : (
            <>
              <table className="ipc-table">
                <thead>
                  <tr>
                    <th>Section</th>
                    <th>Offense</th>
                    <th>Punishment</th>
                  </tr>
                </thead>
                <tbody>
                  {sections.map((item, index) => (
                    <tr key={index} className="result-row">
                      <td className="section-cell">
                        <span className="section-badge">{item.section}</span>
                      </td>
                      <td className="offense-cell">{item.offense}</td>
                      <td className="punishment-cell">
                        <span className="punishment-tag">{item.punishment}</span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {sections.length === 0 && !loading && (
                <div className="no-results">
                  <svg className="no-results-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth="2"
                      d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M12 21a9 9 0 110-18 9 9 0 010 18z"
                    />
                  </svg>
                  <p>No matching sections found</p>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default IPCSectionsTable;
