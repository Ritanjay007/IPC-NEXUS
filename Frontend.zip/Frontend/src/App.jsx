import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Features from './components/Features';
import Footer from './components/Footer';
import RegisterComplaint from './components/RegisterComplaint'; // Import RegisterComplaint
import IPCSectionsTable from './components/Learn_IPC';
import AboutUs from './components/About';
import './App.css';

function App() {
  const branches = ['Civil', 'Patent', 'Criminal', 'Family Law', 'Labour Law', 'More'];

  return (
    <Router>
      <Navbar branches={branches} />
      <Routes>
        {/* Home Page */}
        <Route path="/" element={
          <>
            <Hero />
            <Features />
            <Footer />
          </>
        }/>
        
        
        {/* Register Complaint Page */}
        <Route path="/IPCSections" element={<IPCSectionsTable/>} />
        <Route path="/about" element={<AboutUs/>} />


        <Route path="/register-complaint" element={<RegisterComplaint />} />

      </Routes>
    </Router>
  );
}

export default App;
